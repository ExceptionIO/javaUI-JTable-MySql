inserisci url del tuo database nel metodo getconnection() della classe database.java

fix url in the method getconnection() of class database.java and the other statement and queries