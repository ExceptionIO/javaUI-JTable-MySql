package gestione.magazzino;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Database {
static Connection con=null;;

	public static Connection getConnection() throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		if(con==null) {
			con= DriverManager
	        		.getConnection("your url");
		}
		return con;
	}
	
	//fix id autoincremental number
	public static void fixid() throws ClassNotFoundException, SQLException {
		String query1= "alter table usar.magazzino drop id;";
		String query2="alter table usar.magazzino add id mediumint not null auto_increment primary key;";
		String query3="ALTER TABLE usar.magazzino MODIFY COLUMN oggetti VARCHAR(50)  AFTER id;";
		String query4="ALTER TABLE usar.magazzino MODIFY COLUMN giacenza VARCHAR(50)  AFTER oggetti;";
		
		PreparedStatement ps = con.prepareStatement(query1);
		ps.execute();
		ps = con.prepareStatement(query2);
		ps.execute();
		ps = con.prepareStatement(query3);
		ps.execute();
		ps = con.prepareStatement(query4);
		ps.execute();
	}
	
}
