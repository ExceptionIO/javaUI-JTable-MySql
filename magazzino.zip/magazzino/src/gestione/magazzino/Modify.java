package gestione.magazzino;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class Modify extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField id;
	private JTextField oggetto;
	private JTextField giacenza;


	/**
	 * Create the frame.
	 */
	Connection con=null;
	String query = "SELECT * FROM magazzino";
	public Modify() {
		
		try {
			con=Database.getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(750, 320, 450, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel finestra = new JPanel();
		finestra.setBackground(new Color(240, 240, 240));
		finestra.setBounds(0, 0, 434, 387);
		contentPane.add(finestra);
		
		id = new JTextField();
		id.setColumns(10);
		
		oggetto = new JTextField();
		oggetto.setColumns(10);
		
		giacenza = new JTextField();
		giacenza.setColumns(10);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="update magazzino set oggetti='"+oggetto.getText()+"', giacenza='"+giacenza.getText()+"' where id='"+id.getText()+"'";
					PreparedStatement ps = con.prepareStatement(query);
					ps.execute();
					JOptionPane.showMessageDialog(null,"Modificato!!");
					try(
							PreparedStatement pp = con.prepareStatement(query);
							ResultSet rs = pp.executeQuery();
							){
							App.table.setModel(DbUtils.resultSetToTableModel(rs));
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(139, 0, 0));
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Oggetto:");
		lblNewLabel.setBackground(new Color(178, 34, 34));
		lblNewLabel.setBounds(10, 198, 153, 36);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblGiacenza = new JLabel("Giacenza:");
		lblGiacenza.setHorizontalAlignment(SwingConstants.RIGHT);
		lblGiacenza.setForeground(Color.WHITE);
		lblGiacenza.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGiacenza.setBackground(new Color(178, 34, 34));
		lblGiacenza.setBounds(10, 261, 153, 36);
		panel.add(lblGiacenza);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblId.setForeground(Color.WHITE);
		lblId.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblId.setBackground(new Color(178, 34, 34));
		lblId.setBounds(10, 138, 153, 36);
		panel.add(lblId);
		
		JTextArea txtrPerModificareLa = new JTextArea();
		txtrPerModificareLa.setEditable(false);
		txtrPerModificareLa.setBackground(UIManager.getColor("CheckBox.background"));
		txtrPerModificareLa.setFont(new Font("Times New Roman", Font.BOLD, 15));
		txtrPerModificareLa.setWrapStyleWord(true);
		txtrPerModificareLa.setLineWrap(true);
		txtrPerModificareLa.setRows(3);
		txtrPerModificareLa.setText("Per modificare la quantit\u00E0 o il nome dell'oggetto selezionare l'ID desiderato:");
		GroupLayout gl_finestra = new GroupLayout(finestra);
		gl_finestra.setHorizontalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_finestra.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE)
					.addGroup(gl_finestra.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_finestra.createSequentialGroup()
							.addGap(10)
							.addGroup(gl_finestra.createParallelGroup(Alignment.LEADING)
								.addComponent(id, GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
								.addComponent(oggetto, GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
								.addComponent(giacenza, GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
								.addGroup(gl_finestra.createSequentialGroup()
									.addGap(125)
									.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)))
							.addGap(10))
						.addGroup(gl_finestra.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtrPerModificareLa, GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
							.addContainerGap())))
		);
		gl_finestra.setVerticalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
				.addGroup(gl_finestra.createSequentialGroup()
					.addGap(50)
					.addComponent(txtrPerModificareLa, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(28)
					.addComponent(id, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addGap(26)
					.addComponent(oggetto, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addGap(25)
					.addComponent(giacenza, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
		);
		finestra.setLayout(gl_finestra);
	}
}
