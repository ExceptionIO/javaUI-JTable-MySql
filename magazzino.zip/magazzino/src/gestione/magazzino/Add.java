package gestione.magazzino;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextArea;
import java.awt.SystemColor;

public class Add extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField giacenza;
	private JTextField oggetto;


	/**
	 * Create the frame.
	 */
	Connection con=null;
	
	public Add() {
		String query = "SELECT * FROM magazzino";
		try {
			con=Database.getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(750, 10, 450, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel finestra = new JPanel();
		finestra.setBounds(0, 0, 434, 288);
		contentPane.add(finestra);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(139, 0, 0));
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Oggetto:");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(10, 86, 153, 36);
		panel.add(lblNewLabel);
		
		JLabel lblGiacenza = new JLabel("Giacenza:");
		lblGiacenza.setForeground(new Color(255, 255, 255));
		lblGiacenza.setHorizontalAlignment(SwingConstants.RIGHT);
		lblGiacenza.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblGiacenza.setBounds(10, 157, 153, 36);
		panel.add(lblGiacenza);
		
		oggetto = new JTextField();
		oggetto.setColumns(10);
		
		giacenza = new JTextField();
		giacenza.setColumns(10);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sql = "INSERT INTO magazzino(Oggetti,Giacenza) VALUES('"+oggetto.getText()+"',"+giacenza.getText()+");";
				try {
						PreparedStatement ps = con.prepareStatement(sql);
						ps.execute();
						JOptionPane.showMessageDialog(btnNewButton, "Aggiunto!!");
						try(
							PreparedStatement pp = con.prepareStatement(query);
							ResultSet rs = pp.executeQuery();
							){
							App.table.setModel(DbUtils.resultSetToTableModel(rs));
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					
				}catch(Exception l) {
					l.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JTextArea txtrAggiungiUnoggetto = new JTextArea();
		txtrAggiungiUnoggetto.setEditable(false);
		txtrAggiungiUnoggetto.setWrapStyleWord(true);
		txtrAggiungiUnoggetto.setText("Aggiungi un'oggetto:");
		txtrAggiungiUnoggetto.setRows(3);
		txtrAggiungiUnoggetto.setLineWrap(true);
		txtrAggiungiUnoggetto.setFont(new Font("Times New Roman", Font.BOLD, 15));
		txtrAggiungiUnoggetto.setBackground(SystemColor.menu);
		GroupLayout gl_finestra = new GroupLayout(finestra);
		gl_finestra.setHorizontalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_finestra.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_finestra.createParallelGroup(Alignment.TRAILING)
						.addComponent(giacenza, GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
						.addComponent(oggetto, GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
						.addComponent(txtrAggiungiUnoggetto, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 245, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_finestra.setVerticalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_finestra.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtrAggiungiUnoggetto, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(oggetto, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addComponent(giacenza, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addGap(40)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(38, Short.MAX_VALUE))
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
		);
		finestra.setLayout(gl_finestra);
	}
}
