package gestione.magazzino;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;

public class App {

	private JFrame frame;
	public static JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App window = new App();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App() {
		try {
			con=Database.getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		initialize();
	}
	
	Connection con=null;
	String query = "SELECT * FROM magazzino";

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(50, 50, 700, 650);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		try(
				PreparedStatement ps = con.prepareStatement(query);
				ResultSet rs = ps.executeQuery();
				){
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		JPanel finestra = new JPanel();
		
		JPanel barralt = new JPanel();
		barralt.setBackground(new Color(139, 0, 0));
		
		JButton add = new JButton("Aggiungi");
		add.setForeground(Color.WHITE);
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Add frame = new Add();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		add.setBounds(0, 164, 238, 46);
		add.setFont(new Font("Tahoma", Font.BOLD, 16));
		add.setBackground(new Color(128, 0, 0));
		
		JButton modify = new JButton("Modifica");
		modify.setForeground(Color.WHITE);
		modify.setBounds(0, 209, 238, 46);
		modify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Modify frame = new Modify();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				try(
						PreparedStatement ps = con.prepareStatement(query);
						ResultSet rs = ps.executeQuery();
						){
						table.setModel(DbUtils.resultSetToTableModel(rs));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		modify.setFont(new Font("Tahoma", Font.BOLD, 16));
		modify.setBackground(new Color(128, 0, 0));
		
		JButton eliminate = new JButton("Elimina");
		eliminate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id=Integer.parseInt(JOptionPane.showInputDialog("Inserisci il numero dell'ID che vuoi eliminare"));
				String sql="delete from magazzino where id='"+id+"'";
				
				try {
					PreparedStatement ps = con.prepareStatement(sql);
					ps.execute();
			
				}catch(Exception l) {
					l.printStackTrace();
				}
				
				try(
						PreparedStatement ps = con.prepareStatement(query);
						ResultSet rs = ps.executeQuery();
						){
						table.setModel(DbUtils.resultSetToTableModel(rs));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		eliminate.setForeground(Color.WHITE);
		eliminate.setBounds(0, 254, 238, 46);
		eliminate.setFont(new Font("Tahoma", Font.BOLD, 16));
		eliminate.setBackground(new Color(128, 0, 0));
		
		JButton print = new JButton("Stampa");
		print.setForeground(Color.WHITE);
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					table.print();
				}catch(java.awt.print.PrinterException e){
					System.err.format("Nessuna Stampante trovata", e.getMessage());
				}
			}
		});
		print.setBounds(0, 496, 238, 46);
		print.setFont(new Font("Tahoma", Font.BOLD, 16));
		print.setBackground(new Color(128, 0, 0));
		barralt.setLayout(null);
		barralt.add(add);
		barralt.add(modify);
		barralt.add(eliminate);
		barralt.add(print);
		
		JScrollPane scrollPane = new JScrollPane();
		
		table = new JTable();
		scrollPane.setViewportView(table);
		try(
				PreparedStatement ps = con.prepareStatement(query);
				ResultSet rs = ps.executeQuery();
				){
				table.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setForeground(Color.WHITE);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String value=(String) comboBox.getSelectedItem();
				if(value.equals("Ordina per ID")) {
					try(
							PreparedStatement ps = con.prepareStatement(query);
							ResultSet rs = ps.executeQuery();
							){
							table.setModel(DbUtils.resultSetToTableModel(rs));
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}else if(value.equals("Ordina dalla A alla Z")) {
					String sql="select * from magazzino order by oggetti";
					try(
							PreparedStatement ps = con.prepareStatement(sql);
							ResultSet rs = ps.executeQuery();
							){
							table.setModel(DbUtils.resultSetToTableModel(rs));
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}
			}
		});
		comboBox.setBackground(new Color(220, 20, 60));
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Ordina per ID", "Ordina dalla A alla Z"}));
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(finestra, GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(finestra, GroupLayout.DEFAULT_SIZE, 611, Short.MAX_VALUE)
		);
		
		JButton btnNewButton = new JButton("Aggiorna");
		btnNewButton.setIcon(new ImageIcon("refresh.png"));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(220, 20, 60));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Database.fixid();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try(
						PreparedStatement ps = con.prepareStatement(query);
						ResultSet rs = ps.executeQuery();
						){
						table.setModel(DbUtils.resultSetToTableModel(rs));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			}
		});
		GroupLayout gl_finestra = new GroupLayout(finestra);
		gl_finestra.setHorizontalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_finestra.createSequentialGroup()
					.addComponent(barralt, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
					.addGap(10)
					.addGroup(gl_finestra.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_finestra.createSequentialGroup()
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED, 210, Short.MAX_VALUE)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE))
					.addGap(10))
		);
		gl_finestra.setVerticalGroup(
			gl_finestra.createParallelGroup(Alignment.LEADING)
				.addComponent(barralt, GroupLayout.DEFAULT_SIZE, 611, Short.MAX_VALUE)
				.addGroup(gl_finestra.createSequentialGroup()
					.addGap(11)
					.addGroup(gl_finestra.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addGap(26)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
					.addGap(11))
		);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\CASA\\Downloads\\Logo_del_Corpo_Nazionale_dei_Vigili_del_Fuoco.svg.png"));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(10, 11, 70, 70);
		barralt.add(lblNewLabel);
		finestra.setLayout(gl_finestra);
		frame.getContentPane().setLayout(groupLayout);
	}
}
